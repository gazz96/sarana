
<div class="table-responsive scrollbar bg-white">
    <table class="table fs--1 mb-0 border-top border-200">
        <thead>
            <tr>
                <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="<?php echo e($column['class'] ?? ''); ?>">
                        <?php if($column['sortable'] ?? false): ?>
                            <a href="?sort=<?php echo e($column['name']); ?>&sortBy=<?php echo e(request('sortBy') == 'DESC' ? 'ASC' : 'DESC'); ?>">
                        <?php endif; ?>
                        <?php echo e($column['label'] ?? ''); ?>

                        <?php if($column['sortable'] ?? false): ?>
                            </a>
                        <?php endif; ?>

                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>

        </thead>
        <tbody>
            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <td class="<?php echo e($column['class'] ?? ''); ?>">

                            <?php if(isset($column['callback']) && is_callable($column['callback'])): ?>
                                <?php echo $column['callback']($model); ?>

                                <?php continue; ?>
                            <?php endif; ?>

                            <?php if(isset($model[$column['name'] ?? ''])): ?>
                                <?php echo $model[$column['name']]; ?>

                                <?php continue; ?>
                            <?php endif; ?>
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

            <tfoot>
                <tr>
                    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($column['searchable'] ?? false): ?>
                            <td>
                                <form action="" method="GET">
                                    <input type="text" name="<?php echo e($column['name']); ?>" class="form-control form-control-sm"
                                    placeholder="Search ..." value="<?php echo e(request($column['name'])); ?>">
                                </form>
                            </td>
                        <?php else: ?>
                            <td></td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tfoot>
    </table>
    <?php echo e($models->links()); ?>

</div><?php /**PATH /Users/bagastopati/Public/app/web/sarana/resources/views/components/table.blade.php ENDPATH**/ ?>