<?php $__env->startSection('content'); ?>
    <?php if($problem->id): ?>
        <form action="<?php echo e(route('problems.update', $problem)); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
    <?php else: ?>
        <form action="<?php echo e(route('problems.store')); ?>" method="POST">
    <?php endif; ?>

    <?php echo csrf_field(); ?>

    <div class="container">
        <div class="row">
            <div class="col-12 col-md-12">

                <h3>Form Masalah</h3>

                <?php if($status = session('status')): ?>
                    <div class="alert alert-<?php echo e($status); ?> alert-dismissible fade show" role="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-body">

                        <div class="row mb-3">
                            <div class="mb-3 col-md-3">
                                <label for="i-kode">Kode</label>
                                <input name="code" type="text" class="form-control" id="i-kode" placeholder="Kosongkan untuk nomor otomatis" value="<?php echo e(old('code', $problem->code)); ?>" disabled>
                            </div>

                            <div class="mb-3 col-md-3">
                                <label for="i-date">Tanggal</label>
                                <input name="date" type="date" class="form-control" id="i-date" placeholder="" value="<?php echo e(old('date', $problem->date ?? date('Y-m-d'))); ?>" disabled>
                            </div>
            
                            <div class="mb-3 col-md-3">
                                <label for="i-user_id">Permintaan</label>
                                <input type="text" class="form-control" id="i-user_id" disabled value="<?php echo e($problem->user->name ?? '-'); ?>">
                            </div>
            
                            <div class="mb-3 col-md-3">
                                <label for="i-status">Status</label>
                                <input type="text" class="form-control" id="i-status" disabled value="<?php echo e(\App\Models\Problem::$STATUS[$problem->status ?? 0]); ?>">
                            </div>
                        </div>

                    </div>
                </div>
                

                
            </div>
            <div class="col-12 col-md-12">
                <div class="card">
                    <div class="card-body">

                    
                        <table class="table table-hover table-stripped table-responsive" id="table-problem_items">
                            <thead>
                                <tr>
                                    <th class="text-center">BARANG</th>
                                    <th class="text-center">MASALAH</th>
                                    <th class="text-center">NOTE</th>
                                    <th class="text-center">BIAYA PERBAIKAN</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($problem->id): ?>
                                    <?php $__currentLoopData = $problem->items()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type='hidden' name="items[<?php echo e($index); ?>][id]" value=""/>
                                                <input type='hidden' name="items[<?php echo e($index); ?>][good_id]" value="<?php echo e($item->good_id); ?>"/>
                                                <input type='hidden' name="items[<?php echo e($index); ?>][problem]" value="<?php echo e($item->issue); ?>"/>
                                                <?php echo e($item->good->name ?? '-'); ?>

                                            </td>
                                            <td><?php echo e($item->issue); ?></td>
                                            <td>
                                                <textarea name="items[<?php echo e($index); ?>][note]" class="form-control"><?php echo e($item->note); ?></textarea>
                                            </td>
                                            <td class="text-end" style="width: 200px;">
                                                <input type="number" name="items[<?php echo e($index); ?>][price]" value="<?php echo e($item->price); ?>" class="form-control" />
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="3" class="text-center">GRANDTOTAL</th>
                                    <th id="total" class="text-end"><?php echo e(number_format($problem->items()->sum('price'))); ?></th>
                                    <th colspan="2"></th>
                                </tr>
                            </tfoot>
                        </table>

                    </div>
                </div>

                <div class="d-flex justify-content-end align-items-center">
                    <a href="<?php echo e(route('problems.index')); ?>" class="btn border me-2">Kembali</a>
                    
                    <button type="submit" class="btn btn-success me-2">
                        <i class="bi bi-save me-1"></i>
                        Simpan
                    </button>
                </div>

            </div>
        </div>
    </div>

    </form>

    <!-- Modal -->
    <div class="modal fade" id="modal-item" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Item</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" id="form-problem_item">
                        <div class="mb-3">
                            <label for="i-good_id">Barang</label>
                            <select name="good_id" id="i-good_id" class="form-control">
                                <option value="">Pilih Barang</option>
                                <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $good): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($good->id); ?>"><?php echo e($good->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="i-problem">Masalah</label>
                            <textarea name="problem" id="i-problem" cols="30" rows="5" class="form-control"></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="i-note">Note</label>
                            <textarea name="note" id="i-note" cols="30" rows="5" class="form-control"></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="i-price">Biaya Perbaikan</label>
                            <input name="price" type="number" class="form-control" id="i-price">
                        </div>

                        <button class="btn btn-primary" id="btn-add-item">Tambah</button>
                        <button class="btn btn-primary" id="btn-add-more-item">Tambah & Buat Lagi</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
<script>

    let items = [];

    <?php if($problem->id): ?>
        <?php $__currentLoopData = $problem->items()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        items.push({
            good_id: "<?php echo e($item->good_id); ?>",
            good_name: "<?php echo e($item->good->name ?? '-'); ?>",
            problem: "<?php echo e($item->problem); ?>",
            note: "<?php echo e($item->note); ?>",
            price: "<?php echo e($item->price); ?>"
        })
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


    const addRow = (index, item) => {
        return `
            <tr>
                <td>
                    <input type='hidden' name="items[${index}][id]" value=""/>
                    <input type='hidden' name="items[${index}][good_id]" value="${item.good_id}"/>
                    <input type='hidden' name="items[${index}][problem]" value="${item.problem}"/>
                    <input type='hidden' name="items[${index}][note]" value="${item.note}"/>
                    <input type='hidden' name="items[${index}][price]" value="${item.price}"/>
                    ${item.good_name}
                </td>
                <td>${item.problem}</td>
                <td>${item.price}</td>
                <td>${item.note}</td>
                <td class='text-center'>
                    <button type='button' class='btn btn-sm btn-danger btn-delete-item'>
                        <i class='bi bi-x'></i>
                    </button>
                </td>
            </tr>
        `
    }

    const addProblem = (problem) => {

        if(!problem.good_id) 
        {
            return false;
        }

        let find = items.filter(item => item.good_id === problem.good_id);
        if(!find.length) {
            items.push(problem);
            return problem;
        }
        return false;
    }

    let form_keys = {
        good_id: 'Barang',
        problem: 'Masalah',
        note: 'Catatan',
        price: 'Harga'
    }


    let tableProblemItems = $('#table-problem_items');
    $(document).on('click', '#btn-add-item', function(e){
        e.preventDefault();
        let form = $('#form-problem_item')

        let problem = {
            good_id: form.find('#i-good_id').val(),
            good_name: form.find('#i-good_id').find('option:selected').html(),
            problem: form.find('#i-problem').val(),
            note: form.find('#i-note').val(),
            price: form.find('#i-price').val()
        }

        if(addProblem(problem)) {
            tableProblemItems.find('tbody').empty();
            let total = 0;
            items.map((problem, index) => {
                tableProblemItems.find('tbody').append(addRow(index, problem));
                total += problem.price;
            })
            $('#total').html(total)

            form[0].reset();
            $('#modal-item').modal('hide');
            return;
        }

        Toastify({
            text: "Periksa Kembali",
            className: "bg-warning"
        }).showToast();

        
        
    });

    $(document).on('click', '#btn-add-more-item', function(e){
        e.preventDefault();
        let form = $('#form-problem_item')

        let problem = {
            good_id: form.find('#i-good_id').val(),
            good_name: form.find('#i-good_id').find('option:selected').html(),
            problem: form.find('#i-problem').val(),
            note: form.find('#i-note').val(),
            price: form.find('#i-price').val()
        }

        if(addProblem(problem)) {
            items.map((problem, index) => {
                tableProblemItems.find('tbody').append(addRow(index, problem));
            })
            form[0].reset();
            return;
        }

        Toastify({
            text: "Periksa Kembali",
            className: "bg-warning"
        }).showToast();

        
        
    });

    $(document).on('click', '.btn-delete-item', function(e){
        e.preventDefault();
        $(this).parent().parent().remove();
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bagastopati/Public/app/web/sarana/resources/views/problems/form-teknisi.blade.php ENDPATH**/ ?>