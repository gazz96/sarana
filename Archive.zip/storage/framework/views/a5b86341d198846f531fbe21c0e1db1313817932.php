<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">

            <h3>Masalah</h3>
            
            <form action="">
                <div class="row align-items-center mb-3">
                    <div class="col-md-4">
                        <input name="s" type="text" class="form-control form-control-lg rounded-pill" placeholder="Masukan keyword..." value="<?php echo e(request('s')); ?>">
                    </div>

                    <div class="col-md-4"></div>
                    <?php if(auth()->user()->hasRole(['admin', 'guru', 'pimpinan', 'super user'])): ?>
                    <div class="col-md-4 d-flex align-items-center justify-content-end">
                        <a href="<?php echo e(route('problems.create')); ?>" class="btn btn-lg btn-primary rounded-pill">Tambah</a>
                    </div>
                    <?php endif; ?>
                </div>
            </form>

            <?php if($status = session('status')): ?>
            <div class="alert alert-<?php echo e($status); ?> alert-dismissible fade show" role="alert">
                <?php echo e(session('message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            

            <?php echo $table; ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bagastopati/Public/app/web/sarana/resources/views/problems/index.blade.php ENDPATH**/ ?>