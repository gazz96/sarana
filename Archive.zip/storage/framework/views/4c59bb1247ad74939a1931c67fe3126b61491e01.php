<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            
            <h3>Persetujuan</h3>


            <form action="<?php echo e(route('settings.save')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-4">

                        <div class="card">
                            <div class="card-body">

                                <div class="mb-3">
                                    <label for="i-settings_app_logo">Pegawai</label>
                                    <input name="options[app_logo]" type="file" class="form-control" id="i-settings_app_logo">
                                    <small class="text-info">Pegawai yang dapat melakukan approval pada masalah</small>
                                </div>

                                
                            </div>
                        </div>

                        

                    </div>
                </div>

                <button class="btn btn-primary">Simpan</button>

            </form>
            
        
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bagastopati/Public/app/web/sarana/resources/views/settings/approval.blade.php ENDPATH**/ ?>