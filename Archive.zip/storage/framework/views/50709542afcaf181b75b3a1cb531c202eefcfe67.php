<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">

            <h3>Pegawai</h3>
            
            <form action="">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <input name="s" type="text" class="form-control form-control-lg rounded-pill" placeholder="Masukan keyword..." value="<?php echo e(request('s')); ?>">
                    </div>

                    <div class="col-md-4"></div>

                    <div class="col-md-4 d-flex align-items-center justify-content-end">
                        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-lg btn-primary rounded-pill">Tambah</a>
                    </div>
                </div>
            </form>

            <?php if($status = session('status')): ?>
            <div class="alert alert-<?php echo e($status); ?> alert-dismissible fade show" role="alert">
                <?php echo e(session('message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($user->name); ?>

                                <div class="d-flex align-items-center tr-actions">
                                    <a href="<?php echo e(route('users.edit', $user)); ?>" class="text-decoration-none">Edit</a>
                                    <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" class="ms-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn p-0 text-danger" onclick="return confirm('HAPUS???')">Hapus</button>
                                    </form>
                                </div>
                            </td>
                            <td><?php echo e($user->email); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="d-flex justify-content-end">
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bagastopati/Public/app/web/sarana/resources/views/users/index.blade.php ENDPATH**/ ?>