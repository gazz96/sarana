<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            
            <h3>Pengaturan Umum</h3>


            <form action="<?php echo e(route('settings.save')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-4">

                        <div class="card">
                            <div class="card-body">

                                <div class="mb-3">
                                    <label for="i-settings_app_logo">Logo</label>
                                    <input name="options[app_logo]" type="file" class="form-control" id="i-settings_app_logo">
                                    <?php if($image_url = $option->getByKey('app_logo')): ?>
                                    <img src="<?php echo e(url("uploads/" . $image_url)); ?>" class="img-fluid"/>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3">
                                    <label for="i-settings_app_name">Nama Instansi</label>
                                    <input name="options[app_name]" type="text" class="form-control" value="<?php echo e($option->getByKey('app_name')); ?>" id="i-settings_app_name">
                                </div>

                                <div class="mb-3">
                                    <label for="i-settings_address_instance">Alamat</label>
                                    <textarea name="options[address_instance]" type="text" class="form-control" id="i-settings_address_instance"><?php echo e($option->getByKey('address_instance')); ?></textarea>
                                </div>
                            </div>
                        </div>

                        

                    </div>
                </div>

                <button class="btn btn-primary">Simpan</button>

            </form>
            
        
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bagastopati/Public/app/web/sarana/resources/views/settings/index.blade.php ENDPATH**/ ?>