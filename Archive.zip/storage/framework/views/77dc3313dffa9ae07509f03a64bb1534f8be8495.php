<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            
            <h3 class="mb-3">Laporan Masalah</h3>

            <form action="" class="mb-3">
                <div class="row">
                    <div class="col-md-3">
                        <label for="">Tahun</label>
                        <select name="year" id="i-year" class="form-control" onchange="this.form.submit()">
                            <option value="">Pilih Tahun</option>
                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($year->tahun); ?>" <?php echo e(request('year') == $year->tahun ? 'selected' : ''); ?>><?php echo e($year->tahun); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </form>

            
            
            <?php echo $table; ?>

        
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bagastopati/Public/app/web/sarana/resources/views/reports/problem.blade.php ENDPATH**/ ?>