<?php $__env->startSection('content'); ?>


<?php if($location->id): ?>
<form action="<?php echo e(route('locations.update', $location)); ?>" method="POST">
    <?php echo method_field('PUT'); ?>
<?php else: ?> 
<form action="<?php echo e(route('locations.store')); ?>" method="POST">
<?php endif; ?>
    <?php echo csrf_field(); ?>

    <div class="container my-5">
        <div class="row">
            <div class="col-12 col-md-4">
                
                <h3>Form Lokasi</h3>

                <?php if($status = session('status')): ?>
                <div class="alert alert-<?php echo e($status); ?> alert-dismissible fade show" role="alert">
                    <?php echo e(session('message')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>


                <div class="mb-3">
                    <labael for="i-name">Nama</labael>
                    <input type="text" name="name" class="form-control" id="i-name" value="<?php echo e(old('name', $location->name)); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="d-flex justify-content-end">
                    <a href="<?php echo e(route('locations.index')); ?>" class="btn border me-2">Kembali</a>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bagastopati/Public/app/web/sarana/resources/views/locations/form.blade.php ENDPATH**/ ?>