<!DOCTYPE html>
<!--
  HOW TO USE:
  data-layout: fluid (default), boxed
  data-sidebar-theme: dark (default), colored, light
  data-sidebar-position: left (default), right
  data-sidebar-behavior: sticky (default), fixed, compact
-->
<html lang="en" data-bs-theme="light" data-layout="boxed" data-sidebar-theme="light" data-sidebar-position="left"
    data-sidebar-behavior="sticky">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Dashboard Template">
    <meta name="author" content="Bagas Topati">

    <title>Sarana & Prasana Sekolah</title>

    <link rel="canonical" href="https://instagram.com/bagas.topati" />
    <link rel="shortcut icon" href="img/favicon.ico">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href="<?php echo e(url('css/custom-main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('appstack/css/app.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

    <!-- BEGIN SETTINGS -->
    <!-- Remove this after purchasing -->
    
    <!-- END SETTINGS -->

    
    <?php echo $__env->yieldContent('header'); ?>
</head>

<body>
    <div class="wrapper">
        <nav id="sidebar" class="sidebar">
            <div class="sidebar-content js-simplebar">
                <?php if($app_logo = $option->getByKey('app_logo')): ?>
                <a class="sidebar-brand" href="<?php echo e(url('dashboard')); ?>">
                    <img src="<?php echo e(url("uploads/{$app_logo}")); ?>" alt="Logo" class="img-fluid">
                </a>
                <?php endif; ?>

                <ul class="sidebar-nav">
                    <li class="sidebar-header fw-semibold">
                        Navigasi
                    </li>
                   
                    <?php if(auth()->user()->hasRole(['admin', 'super user'])): ?>

                    <li class="sidebar-item">
                        <a href="<?php echo e(url('dashboard')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a href="<?php echo e(route('goods.index')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="list"></i>
                            <span>Inventaris</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a href="<?php echo e(route('locations.index')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="file"></i>
                            <span>Lokasi</span>
                        </a>
                    </li>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('problems.index')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="alert-triangle"></i>
                            <span>Masalah</span>
                        </a>
                    </li>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('users.index')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="users"></i>
                            <span>Pegawai</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a href="<?php echo e(route('profile')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="user-check"></i>
                            <span>Profile</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a data-bs-target="#navbar-reports" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="align-middle" data-lucide="pie-chart"></i> <span
                                class="align-middle">Laporan</span>
                            
                        </a>
                        <ul id="navbar-reports" class="sidebar-dropdown list-unstyled collapse " data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('reports.problem')); ?>">Masalah</a>
                            </li>
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('reports.finance')); ?>">Keuangan</a>
                            </li>
                            
                        </ul>
                    </li>
                
                    <li class="sidebar-item">
                        <a data-bs-target="#navbar-settings" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="align-middle" data-lucide="sliders"></i> <span
                                class="align-middle">Pengaturan</span>
                            
                        </a>
                        <ul id="navbar-settings" class="sidebar-dropdown list-unstyled collapse " data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('settings.general')); ?>">Umum</a>
                            </li>
                            
                        </ul>
                    </li>
                  
                    <?php endif; ?>

                    <?php if(auth()->user()->hasRole('teknisi')): ?>

                    <li class="sidebar-item">
                        <a href="<?php echo e(url('dashboard')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('problems.index')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="alert-triangle"></i>
                            <span>Masalah</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a href="<?php echo e(route('profile')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="user-check"></i>
                            <span>Profile</span>
                        </a>
                    </li>
                  
                    <?php endif; ?>

                    <?php if(auth()->user()->hasRole(['lembaga', 'keuangan'])): ?>

                    <li class="sidebar-item">
                        <a href="<?php echo e(url('dashboard')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('problems.index')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="alert-triangle"></i>
                            <span>Masalah</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a href="<?php echo e(route('profile')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="user-check"></i>
                            <span>Profile</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a data-bs-target="#navbar-reports" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="align-middle" data-lucide="pie-chart"></i> <span
                                class="align-middle">Laporan</span>
                            
                        </a>
                        <ul id="navbar-reports" class="sidebar-dropdown list-unstyled collapse " data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('reports.problem')); ?>">Masalah</a>
                            </li>
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('reports.finance')); ?>">Keuangan</a>
                            </li>
                            
                        </ul>
                    </li>
                  
                    <?php endif; ?>


                    <?php if(auth()->user()->hasRole('guru')): ?>

                    <li class="sidebar-item">
                        <a href="<?php echo e(url('dashboard')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('problems.index')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="alert-triangle"></i>
                            <span>Masalah</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a href="<?php echo e(route('profile')); ?>" class="sidebar-link">
                            <i class="align-middle text-body" data-lucide="user-check"></i>
                            <span>Profile</span>
                        </a>
                    </li>
                  
                    <?php endif; ?>

                </ul>

               
            </div>
        </nav>
        <div class="main">
            <nav class="navbar navbar-expand navbar-bg">
                <a class="sidebar-toggle">
                    <i class="hamburger align-self-center"></i>
                </a>

        

                <div class="navbar-collapse collapse">
                    <ul class="navbar-nav navbar-align">
                        <li class="nav-item dropdown">
                            <a class="nav-icon dropdown-toggle" href="#" id="messagesDropdown"
                                data-bs-toggle="dropdown">
                                <div class="position-relative">
                                    <i class="align-middle text-body" data-lucide="message-circle"></i>
                                    <span class="indicator">4</span>
                                </div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0"
                                aria-labelledby="messagesDropdown">
                                <div class="dropdown-menu-header">
                                    <div class="position-relative">
                                        4 New Messages
                                    </div>
                                </div>
                                <div class="list-group">
                                    <a href="#" class="list-group-item">
                                        <div class="row g-0 align-items-center">
                                            <div class="col-2">
                                                <img src="img/avatars/avatar-5.jpg" class="img-fluid rounded-circle"
                                                    alt="Ashley Briggs" width="40" height="40">
                                            </div>
                                            <div class="col-10 ps-2">
                                                <div>Ashley Briggs</div>
                                                <div class="text-muted small mt-1">Nam pretium turpis et arcu. Duis
                                                    arcu tortor.</div>
                                                <div class="text-muted small mt-1">15m ago</div>
                                            </div>
                                        </div>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <div class="row g-0 align-items-center">
                                            <div class="col-2">
                                                <img src="img/avatars/avatar-2.jpg" class="img-fluid rounded-circle"
                                                    alt="Carl Jenkins" width="40" height="40">
                                            </div>
                                            <div class="col-10 ps-2">
                                                <div>Carl Jenkins</div>
                                                <div class="text-muted small mt-1">Curabitur ligula sapien euismod
                                                    vitae.</div>
                                                <div class="text-muted small mt-1">2h ago</div>
                                            </div>
                                        </div>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <div class="row g-0 align-items-center">
                                            <div class="col-2">
                                                <img src="img/avatars/avatar-4.jpg" class="img-fluid rounded-circle"
                                                    alt="Stacie Hall" width="40" height="40">
                                            </div>
                                            <div class="col-10 ps-2">
                                                <div>Stacie Hall</div>
                                                <div class="text-muted small mt-1">Pellentesque auctor neque nec urna.
                                                </div>
                                                <div class="text-muted small mt-1">4h ago</div>
                                            </div>
                                        </div>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <div class="row g-0 align-items-center">
                                            <div class="col-2">
                                                <img src="img/avatars/avatar-3.jpg" class="img-fluid rounded-circle"
                                                    alt="Bertha Martin" width="40" height="40">
                                            </div>
                                            <div class="col-10 ps-2">
                                                <div>Bertha Martin</div>
                                                <div class="text-muted small mt-1">Aenean tellus metus, bibendum sed,
                                                    posuere ac, mattis non.</div>
                                                <div class="text-muted small mt-1">5h ago</div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="dropdown-menu-footer">
                                    <a href="#" class="text-muted">Show all messages</a>
                                </div>
                            </div>
                        </li>
                        
                        
                        <li class="nav-item dropdown">
                            <a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#"
                                data-bs-toggle="dropdown">
                                <i class="align-middle" data-lucide="settings"></i>
                            </a>

                            <a class="nav-link dropdown-toggle d-none d-sm-inline-block" 
                                href="#"
                                data-bs-toggle="dropdown">
                                
                                <span><?php echo e(auth()->user()->name ?? '-'); ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><i class="align-middle me-1"
                                        data-lucide="user"></i> Profile</a>
                                
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo e(route('settings.general')); ?>">Pengaturan</a>
                                
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Sign out</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>

            <main class="content">
                
                <?php echo $__env->yieldContent('content'); ?>
            </main>

            
        </div>
    </div>

    <script src="<?php echo e(url('appstack/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('appstack/js/app.js')); ?>"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

    <?php echo $__env->yieldContent('footer'); ?>
    

</body>

</html>
<?php /**PATH /Users/bagastopati/Public/app/web/sarana/resources/views/layouts.blade.php ENDPATH**/ ?>