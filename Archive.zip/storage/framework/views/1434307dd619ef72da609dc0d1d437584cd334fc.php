<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Responsive Bootstrap 5 Admin &amp; Dashboard Template">
        <meta name="author" content="Bootlab">
    
        <title>Sign In | <?php echo e($option->getByKey('app_name')); ?></title>
    
        <link rel="canonical" href="https://appstack.bootlab.io/auth-sign-in.html">
        <link rel="shortcut icon" href="img/favicon.ico">
    
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&amp;display=swap" rel="stylesheet">
    
        <link href="<?php echo e(url('appstack/css/app.css')); ?>" rel="stylesheet">
    </head>

    <body>

        <div class="auth-full-page d-flex">
            <div class="auth-form p-3">
                <?php if($status = session('status')): ?>
                    <div class="alert alert-<?php echo e($status); ?> alert-dismissible fade show" role="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="text-center">
                    <h1 class="h2">Selamat datang kembali!</h1>
                    <p class="lead">
                        Sign in to your account to continue
                    </p>
                </div>

                <div class="mb-3">
                    
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="i-email">Email</label>
                            <input type="email" class="form-control form-control-lg rounded-pill" value="<?php echo e(old('email')); ?>" name="email" placeholder="Masukan Email" id="i-email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="d-block invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="i-password">Password</label>
                            <input type="password" class="form-control form-control-lg rounded-pill" id="i-password" name="password" placeholder="Masukan Password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="d-block invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button class="btn btn-lg btn-primary d-block w-100 rounded-pill">Masuk</button>
                    </form>
                </div>

                
            </div>
        </div>

    </body>
    
</html>
<?php /**PATH /Users/bagastopati/Public/app/web/sarana/resources/views/auth.blade.php ENDPATH**/ ?>