<?php 

namespace App\Sarana;

class Abilities
{


}